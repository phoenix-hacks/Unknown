import React, { useEffect } from 'react';
import { Text, StyleSheet, TouchableOpacity, Animated } from 'react-native';

type GridBlockProps = {
  question: string;
  isUnlocked: boolean;
  onPress: () => void;
};

const GridBlock: React.FC<GridBlockProps> = ({ question, isUnlocked, onPress }) => {
  // Add debug log to verify props
  console.log(`Rendering GridBlock: ${question}, isUnlocked: ${isUnlocked}`);

  return (
    <TouchableOpacity
      style={[styles.block, isUnlocked ? styles.unlocked : styles.locked]}
      onPress={() => {
        console.log(`Clicked block: ${question}`);
        onPress();
      }}
      disabled={!isUnlocked} // Ensure blocks are only clickable when unlocked
    >
      <Text style={styles.text}>{isUnlocked ? 'Unlocked' : 'Locked'}</Text>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  block: {
    width: 100,
    height: 100,
    margin: 10,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 8,
    borderWidth: 2,
  },
  locked: {
    backgroundColor: '#ccc',
    borderColor: '#999',
  },
  unlocked: {
    backgroundColor: '#4caf50',
    borderColor: '#2e7d32',
  },
  text: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#fff',
  },
});

export default GridBlock;
