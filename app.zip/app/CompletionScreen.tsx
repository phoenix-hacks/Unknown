import React, { useState } from 'react';
import { View, StyleSheet, Text, Image } from 'react-native';
import LottieView from 'lottie-react-native';

const CompletionScreen: React.FC = () => {
  const [animationCompleted, setAnimationCompleted] = useState(false);

  const handleAnimationFinish = () => {
    setAnimationCompleted(true); // Set state to show the final content
  };

  return (
    <View style={styles.container}>
      {!animationCompleted ? (
        // Display the animation while loading
        <LottieView
          source={require('../assets/animations/correct.json')} // Replace with your animation file
          autoPlay
          loop={false}
          style={styles.animation}
          onAnimationFinish={handleAnimationFinish}
        />
      ) : (
        // Show the congratulatory message and image after the animation
        <>
          <Text style={styles.congratsText}>
            🎉 Congratulations! You've completed the game! 🎉
          </Text>
          <Image
            source={require('../assets/images/full-image.png')}
            style={styles.fullImage}
            onError={() => console.error('Failed to load the full image.')}
          />
        </>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#f0f8ff',
  },
  animation: {
    width: 300,
    height: 300,
  },
  congratsText: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
    color: '#333',
  },
  fullImage: {
    width: '90%',
    height: '70%',
    resizeMode: 'contain',
    borderRadius: 10,
    borderWidth: 2,
    borderColor: '#ddd',
  },
});

export default CompletionScreen;
