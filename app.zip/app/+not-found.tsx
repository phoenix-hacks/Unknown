import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Image } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { RootStackParamList } from '../types';

type NotFoundNavigationProp = NativeStackNavigationProp<RootStackParamList, '+not-found'>;

const NotFoundScreen: React.FC = () => {
  const navigation = useNavigation<NotFoundNavigationProp>();

  const handleGetStarted = () => {
    navigation.navigate('SignInScreen'); // Ensure this matches your types
  };

  return (
    <View style={styles.container}>
      <Image
        source={require('../assets/getstartedd.png')} // Replace with actual image path
        style={styles.backgroundImage}
        resizeMode="cover"
      />
      <View style={styles.bottomContainer}>
        <Text style={styles.title}>Welcome!</Text>
        <Text style={styles.subtitle}>Let's get you started on the right path.</Text>
        <TouchableOpacity style={styles.button} onPress={handleGetStarted}>
          <Text style={styles.buttonText}>Get Started</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  backgroundImage: {
    position: 'absolute',
    width: '100%',
    height: '100%',
  },
  bottomContainer: {
    position: 'absolute',
    bottom: 30,
    width: '100%',
    alignItems: 'center',
    paddingHorizontal: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 10,
  },
  subtitle: {
    fontSize: 16,
    color: '#ddd',
    marginBottom: 20,
    textAlign: 'center',
  },
  button: {
    backgroundColor: '#FA4A0C',
    paddingVertical: 10,
    paddingHorizontal: 30,
    borderRadius: 8,
  },
  buttonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
});

export default NotFoundScreen;
