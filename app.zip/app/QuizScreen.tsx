import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Alert,
  ActivityIndicator,
} from 'react-native';
import * as Location from 'expo-location';

type Question = {
  question: string;
  correct_answer: string;
  incorrect_answers: string[];
};

const QuizScreen: React.FC = () => {
  const [location, setLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [quizStarted, setQuizStarted] = useState(false);
  const [loading, setLoading] = useState(false);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);

  // Function to fetch location
  const fetchLocation = async () => {
    setLoading(true);
    const { status } = await Location.requestForegroundPermissionsAsync();
    if (status !== 'granted') {
      setLoading(false);
      Alert.alert('Permission Denied', 'Location permission is required to use this feature.');
      return;
    }

    try {
      const locationResult = await Location.getCurrentPositionAsync({
        accuracy: Location.Accuracy.High,
      });
      const { latitude, longitude } = locationResult.coords;
      setLocation({ latitude, longitude });
      setLoading(false);

      Alert.alert('Location Fetched', `Lat: ${latitude}, Long: ${longitude}`);
      if (isInBengaluru(latitude, longitude)) {
        startBengaluruQuiz();
      } else {
        Alert.alert('Not in Bengaluru', 'This quiz is only available for Bengaluru.');
      }
    } catch (error) {
      setLoading(false);
      Alert.alert('Error Fetching Location', 'Ensure location services are enabled.');
    }
  };

  // Function to check if the location is in Bengaluru
  const isInBengaluru = (latitude: number, longitude: number): boolean => {
    // Approximate bounding box for Bengaluru
    const minLat = 12.85;
    const maxLat = 13.10;
    const minLon = 77.48;
    const maxLon = 77.68;

    return latitude >= minLat && latitude <= maxLat && longitude >= minLon && longitude <= maxLon;
  };

  // Function to start Bengaluru-specific quiz
  const startBengaluruQuiz = () => {
    const bengaluruQuestions = [
      {
        question: "What is the official language of Bengaluru?",
        correct_answer: "Kannada",
        incorrect_answers: ["Telugu", "Tamil", "Hindi"],
      },
      {
        question: "Bengaluru is known as the ________ of India.",
        correct_answer: "All of the above",
        incorrect_answers: ["Silicon Valley", "Garden City", "IT Hub"],
      },
      {
        question: "Which iconic park is located in the heart of Bengaluru?",
        correct_answer: "Cubbon Park",
        incorrect_answers: ["Lalbagh Botanical Garden", "Nandi Hills", "Bannerghatta Park"],
      },
      {
        question: "JP Nagar is named after which famous Indian personality?",
        correct_answer: "Jayaprakash Narayan",
        incorrect_answers: ["Jawaharlal Nehru", "Jagannath Prasad", "Jyotiba Phule"],
      },
      {
        question: "What is the name of Bengaluru’s international airport?",
        correct_answer: "Kempegowda International Airport",
        incorrect_answers: ["HAL International Airport", "Bengaluru Central Airport", "Bangalore Air Terminal"],
      },
      {
        question: "Which major IT company has its headquarters in Bengaluru?",
        correct_answer: "Infosys",
        incorrect_answers: ["TCS", "HCL", "Wipro"],
      },
      {
        question: "Which famous temple is located in JP Nagar?",
        correct_answer: "Ragigudda Anjaneya Temple",
        incorrect_answers: ["Iskcon Temple", "Raghavendra Swamy Mutt", "Dharmaraya Temple"],
      },
      {
        question: "Bengaluru was earlier known as?",
        correct_answer: "Bangalore",
        incorrect_answers: ["Mysuru", "Madras", "Bijapur"],
      },
      {
        question: "Which famous palace is located in Bengaluru?",
        correct_answer: "Both Bangalore Palace and Tipu Sultan's Summer Palace",
        incorrect_answers: ["Mysore Palace", "Bangalore Palace", "Tipu Sultan's Summer Palace"],
      },
      {
        question: "What is Bengaluru's average elevation above sea level?",
        correct_answer: "800 meters",
        incorrect_answers: ["500 meters", "1000 meters", "1200 meters"],
      },
    ];

    setQuestions(bengaluruQuestions);
    setQuizStarted(true);
  };

  // Handle answer selection
  const handleAnswer = (selectedAnswer: string) => {
    const currentQuestion = questions[currentQuestionIndex];

    if (selectedAnswer === currentQuestion.correct_answer) {
      Alert.alert('Correct!', 'You selected the correct answer!', [
        {
          text: 'Next',
          onPress: () => {
            if (currentQuestionIndex + 1 < questions.length) {
              setCurrentQuestionIndex(currentQuestionIndex + 1);
            } else {
              Alert.alert('Quiz Complete', 'You have completed the quiz!');
              setQuizStarted(false);
            }
          },
        },
      ]);
    } else {
      Alert.alert('Incorrect', 'Try again.');
    }
  };

  // If loading
  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#0000ff" />
        <Text>Fetching location...</Text>
      </View>
    );
  }

  // If quiz has not started
  if (!quizStarted) {
    return (
      <View style={styles.container}>
        <TouchableOpacity style={styles.button} onPress={fetchLocation}>
          <Text style={styles.buttonText}>Fetch Location</Text>
        </TouchableOpacity>
      </View>
    );
  }

  // During quiz
  const currentQuestion = questions[currentQuestionIndex];
  const options = [
    ...currentQuestion.incorrect_answers,
    currentQuestion.correct_answer,
  ].sort(() => Math.random() - 0.5); // Shuffle options

  return (
    <View style={styles.container}>
      <Text style={styles.question}>
        Q{currentQuestionIndex + 1}: {currentQuestion.question}
      </Text>

      {options.map((option, index) => (
        <TouchableOpacity
          key={index}
          style={styles.option}
          onPress={() => handleAnswer(option)}
        >
          <Text style={styles.optionText}>{option}</Text>
        </TouchableOpacity>
      ))}

      <Text style={styles.footer}>
        Question {currentQuestionIndex + 1} of {questions.length}
      </Text>
    </View>
  );
};

const styles = StyleSheet.create({
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  container: {
    flex: 1,
    padding: 20,
    justifyContent: 'center',
    backgroundColor: '#f0f8ff',
  },
  button: {
    backgroundColor: '#4caf50',
    padding: 15,
    borderRadius: 8,
    alignItems: 'center',
    marginVertical: 10,
  },
  buttonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
  question: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  option: {
    backgroundColor: '#e8f5e9',
    padding: 15,
    borderRadius: 8,
    marginVertical: 10,
    alignItems: 'center',
  },
  optionText: {
    fontSize: 16,
    color: '#333',
  },
  footer: {
    marginTop: 20,
    textAlign: 'center',
    fontSize: 14,
    color: '#666',
  },
});

export default QuizScreen;
