import React, { useEffect } from 'react';
import { Stack, useRouter } from 'expo-router';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function RootLayout() {
  const router = useRouter();

  useEffect(() => {
    const checkUserLoggedIn = async () => {
      try {
        const username = await AsyncStorage.getItem('username');
        if (!username) {
          console.log('No user found, redirecting to Sign In.');
          router.replace('/SignInScreen');
        } else {
          console.log(`Welcome back, ${username}`);
          router.replace('/HomeScreen');
        }
      } catch (error) {
        console.error('Error checking user login status:', error);
      }
    };

    checkUserLoggedIn();
  }, []);

  return (
    <Stack>
      <Stack.Screen
        name="SignInScreen"
        options={{
          title: 'Sign In',
          headerShown: true,
        }}
      />
      <Stack.Screen
        name="HomeScreen"
        options={{
          title: 'Home',
          headerShown: true,
        }}
      />
      <Stack.Screen
        name="GridScreen"
        options={{
          title: 'Grid Game',
          headerShown: true,
        }}
      />
      <Stack.Screen
        name="CompletionScreen"
        options={{
          title: 'Congratulations!',
          headerShown: true,
        }}
      />
      <Stack.Screen
        name="QuestionScreen"
        options={{
          title: 'Question',
          headerShown: true,
        }}
      />
      <Stack.Screen
        name="QuizScreen"
        options={{
          title: 'Location-Based Quiz',
          headerShown: true,
        }}
      />
      <Stack.Screen
        name="+not-found"
        options={{
          title: 'Introduction',
          headerShown: true,
        }}
      />
    </Stack>
  );
}
