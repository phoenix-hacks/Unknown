import React, { useEffect, useState } from 'react';
import { View, StyleSheet, Button, Text, TouchableOpacity, Image, Alert } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { RootStackParamList } from '../types';

const NUM_ROWS = 3;
const NUM_COLUMNS = 3;

const imageParts: Record<string, any> = {
  '0': require('../assets/images/part-1.jpeg'),
  '1': require('../assets/images/part-2.jpeg'),
  '2': require('../assets/images/part-3.jpeg'),
  '3': require('../assets/images/part-4.jpeg'),
  '4': require('../assets/images/part-5.jpeg'),
  '5': require('../assets/images/part-6.jpeg'),
  '6': require('../assets/images/part-7.jpeg'),
  '7': require('../assets/images/part-8.jpeg'),
  '8': require('../assets/images/part-9.jpeg'),
};

const getQuestionForBlock = (index: number): string => {
  const questions = [
    "I'm not far, and I'm green and wide, with open skies and paths to stride. Guess my name!",
    "A cozy spot where laughter’s heard, aromatic brews, every sip a word. Guess this café!",
    "With stores galore, it’s a shopper’s spree, a movie, a bite, or fashion to see. Guess the mall!",
    "I’m the stop on a journey of speed, I help you travel wherever you need. Name the metro station!",
    "Hot and tasty, it’s student fuel. From spicy bites to sweet delights, what’s the canteen’s favorite food?",
    "Guiding futures with advice so sound, helping students till jobs are found. Who’s the placement coordinator?",
    "A number that’s neither too high nor low, it reflects where your career might go. Guess the average package!",
    "Count the programs, and you'll find, how RVITM molds brilliant minds. How many courses are there?",
    "With events and tasks that leave you amazed, which club earns all the praise at RVITM?",
  ];
  return questions[index] || "Default question";
};

const getLocationForBlock = (index: number): { latitude: number; longitude: number } => {
  const locations = [
    { latitude: 12, longitude: 77 }, // Example location for question 1
    { latitude: 12.9728, longitude: 77.5951 }, // Example location for question 2
    { latitude: 12.9250, longitude: 77.5938 }, // Example location for question 3
    { latitude: 12.9304, longitude: 77.6010 }, // Example location for question 4
    { latitude: 12.9716, longitude: 77.5946 }, // Example location for question 5
    { latitude: 12.9716, longitude: 77.5946 }, // Example location for question 6
    { latitude: 12.9716, longitude: 77.5946 }, // Example location for question 7
    { latitude: 12.9716, longitude: 77.5946 }, // Example location for question 8
    { latitude: 12.9716, longitude: 77.5946 }, // Example location for question 9
  ];
  return locations[index] || { latitude: 0, longitude: 0 };
};

type GridScreenNavigationProp = NativeStackNavigationProp<RootStackParamList, 'GridScreen'>;

const GridScreen: React.FC = () => {
  const navigation = useNavigation<GridScreenNavigationProp>();

  const [gridData, setGridData] = useState(
    Array.from({ length: NUM_ROWS * NUM_COLUMNS }, (_, index) => ({
      id: index.toString(),
      question: getQuestionForBlock(index),
      location: getLocationForBlock(index),
      isUnlocked: index === 0,
      isCompleted: false,
    }))
  );

  const loadGridData = async () => {
    try {
      const storedData = await AsyncStorage.getItem('gridData');
      if (storedData) {
        setGridData(JSON.parse(storedData));
      }
    } catch (error) {
      console.error('Error loading grid data:', error);
    }
  };

  const saveGridData = async (data: typeof gridData) => {
    try {
      await AsyncStorage.setItem('gridData', JSON.stringify(data));
    } catch (error) {
      console.error('Error saving grid data:', error);
    }
  };

  const handleQuestionAnswered = async (blockId: string) => {
    const currentIndex = gridData.findIndex((block) => block.id === blockId);

    if (currentIndex === -1) return;

    const updatedData = [...gridData];
    updatedData[currentIndex].isCompleted = true;

    if (currentIndex + 1 < updatedData.length) {
      updatedData[currentIndex + 1].isUnlocked = true;
    }

    setGridData(updatedData);
    await saveGridData(updatedData);
  };

  const handleBlockPress = (block: { id: string; question: string; location: { latitude: number; longitude: number }; isUnlocked: boolean }) => {
    if (block.isUnlocked) {
      navigation.navigate('QuestionScreen', {
        question: block.question,
        location: block.location,
        blockId: block.id,
        onAnswered: handleQuestionAnswered,
      });
    } else {
      Alert.alert('Locked', 'Complete the current block to unlock this one.');
    }
  };

  const resetGame = async () => {
    const initialGridData = Array.from({ length: NUM_ROWS * NUM_COLUMNS }, (_, index) => ({
      id: index.toString(),
      question: getQuestionForBlock(index),
      location: getLocationForBlock(index),
      isUnlocked: index === 0,
      isCompleted: false,
    }));
    setGridData(initialGridData);
    await saveGridData(initialGridData);
  };

  useEffect(() => {
    loadGridData();
  }, []);

  return (
    <View style={styles.container}>
      <Button title="Restart Game" onPress={resetGame} />
      <View style={styles.gridContainer}>
        {gridData.map((block) => (
          <TouchableOpacity
            key={block.id}
            style={[
              styles.block,
              block.isUnlocked ? styles.unlockedBlock : styles.lockedBlock,
              block.isCompleted ? styles.completedBlock : null,
            ]}
            onPress={() => handleBlockPress(block)}
          >
            {block.isCompleted && (
              <Image
                source={imageParts[block.id as keyof typeof imageParts]}
                style={styles.image}
                resizeMode="contain"
              />
            )}
            {!block.isCompleted && (
              <Text style={styles.blockText}>
                {block.isUnlocked ? block.question : '🔒'}
              </Text>
            )}
          </TouchableOpacity>
        ))}
      </View>
      {gridData.every((block) => block.isCompleted) && (
        <View style={styles.completionContainer}>
          <Text style={styles.completionText}>Congratulations! 🎉</Text>
          <Button
            title="Reveal Full Image"
            onPress={() => navigation.navigate('CompletionScreen')}
          />
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 10,
    backgroundColor: '#f0f0f0',
  },
  gridContainer: {
    flex: 1,
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
  },
  block: {
    width: 100,
    height: 100,
    margin: 5,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderRadius: 8,
  },
  unlockedBlock: {
    backgroundColor: '#4caf50',
    borderColor: '#2e7d32',
  },
  lockedBlock: {
    backgroundColor: '#ccc',
    borderColor: '#999',
  },
  completedBlock: {
    backgroundColor: '#2196f3',
    borderColor: '#0d47a1',
  },
  blockText: {
    fontSize: 16,
    color: '#fff',
    fontWeight: 'bold',
    textAlign: 'center',
  },
  image: {
    width: '100%',
    height: '100%',
  },
  completionContainer: {
    marginTop: 20,
    alignItems: 'center',
  },
  completionText: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
    textAlign: 'center',
    color: '#333',
  },
});

export default GridScreen;
