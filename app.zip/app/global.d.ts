declare module 'react-native-confetti-cannon' {
    import { Component } from 'react';
    import { StyleProp, ViewStyle } from 'react-native';
  
    export interface ConfettiProps {
      count?: number;
      origin?: { x: number; y: number };
      fallSpeed?: number;
      colors?: string[];
      explosionSpeed?: number;
      fadeOut?: boolean;
      autoStart?: boolean;
      onAnimationEnd?: () => void;
      style?: StyleProp<ViewStyle>;
    }
  
    export default class ConfettiCannon extends Component<ConfettiProps> {}
  }
  