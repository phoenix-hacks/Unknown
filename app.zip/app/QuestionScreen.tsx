import React, { useState, useEffect } from 'react';
import { View, Text, Button, Alert, StyleSheet } from 'react-native';
import * as Location from 'expo-location';
import { useRoute, useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { RootStackParamList } from '../types';

type QuestionScreenNavigationProp = NativeStackNavigationProp<
  RootStackParamList,
  'QuestionScreen'
>;

const QuestionScreen: React.FC = () => {
  const route = useRoute();
  const navigation = useNavigation<QuestionScreenNavigationProp>();

  const { question, location, blockId, onAnswered } = route.params as {
    question: string;
    location: { latitude: number; longitude: number };
    blockId: string;
    onAnswered: (blockId: string) => void;
  };

  const [userLocation, setUserLocation] = useState<{
    latitude: number;
    longitude: number;
  } | null>(null);

  const requestLocationPermission = async () => {
    const { status } = await Location.requestForegroundPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert(
        'Permission Denied',
        'Location permission is required to use this feature.'
      );
      return false;
    }
    return true;
  };

  const fetchLocation = async () => {
    const hasPermission = await requestLocationPermission();
    if (!hasPermission) return;

    try {
      const location = await Location.getCurrentPositionAsync({
        accuracy: Location.Accuracy.High,
      });
      const { latitude, longitude } = location.coords;
      setUserLocation({ latitude, longitude });
      Alert.alert('Location Fetched', `Lat: ${latitude}, Long: ${longitude}`);
    } catch (error) {
      console.error('Error fetching location:', error);
      Alert.alert(
        'Error Fetching Location',
        'Ensure location services are enabled and try again.'
      );
    }
  };

  const handleAnswerSubmit = () => {
    if (
      userLocation &&
      Math.abs(userLocation.latitude - location.latitude) < 0.001 &&
      Math.abs(userLocation.longitude - location.longitude) < 0.001
    ) {
      Alert.alert('Correct!', 'You are at the correct location!', [
        {
          text: 'OK',
          onPress: () => {
            onAnswered(blockId);
            navigation.navigate('GridScreen');
          },
        },
      ]);
    } else {
      Alert.alert('Incorrect', 'You are not at the correct location. Try again.');
    }
  };

  useEffect(() => {
    requestLocationPermission();
  }, []);

  return (
    <View style={styles.container}>
      <Text style={styles.question}>{question}</Text>

      {userLocation && (
        <View style={styles.locationInfo}>
          <Text style={styles.infoHeader}>Your Location:</Text>
          <Text style={styles.infoText}>Lat: {userLocation.latitude}</Text>
          <Text style={styles.infoText}>Long: {userLocation.longitude}</Text>
        </View>
      )}

      <View style={styles.buttonsContainer}>
        <Button title="Fetch Current Location" onPress={fetchLocation} />
        <Button title="Submit Answer" onPress={handleAnswerSubmit} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f0f8ff',
  },
  question: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  locationInfo: {
    marginBottom: 20,
    backgroundColor: '#e8f5e9',
    padding: 10,
    borderRadius: 8,
    width: '90%',
    alignItems: 'center',
  },
  infoHeader: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 5,
    color: '#2e7d32',
  },
  infoText: {
    fontSize: 14,
    color: '#333',
  },
  buttonsContainer: {
    width: '90%',
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
});

export default QuestionScreen;
