import React from 'react';
import {
  View,
  StyleSheet,
  TouchableOpacity,
  Image,
  ImageBackground,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '../types';

type HomeScreenNavigationProp = NativeStackNavigationProp<
  RootStackParamList,
  'HomeScreen'
>;

const HomeScreen: React.FC = () => {
  const navigation = useNavigation<HomeScreenNavigationProp>();

  return (
    <ImageBackground
      source={require('../assets/home.png')} // Background image
      style={styles.background}
    >
      <View style={styles.container}>
        {/* First Image/Button for "Start Grid Game" */}
        <TouchableOpacity
          style={styles.imageButton}
          onPress={() => navigation.navigate('GridScreen')}
        >
          <Image
            source={require('../assets/explore.png')} // Replace with your image path
            style={styles.image}
            resizeMode="contain"
          />
        </TouchableOpacity>

        {/* Second Image/Button for "Play Location Quiz" */}
        <TouchableOpacity
          style={styles.imageButton}
          onPress={() => navigation.navigate('QuizScreen')}
        >
          <Image
            source={require('../assets/play.png')} // Replace with your image path
            style={styles.image}
            resizeMode="contain"
          />
        </TouchableOpacity>
      </View>
    </ImageBackground>
  );
};

const styles = StyleSheet.create({
  background: {
    flex: 1,
    resizeMode: 'cover',
  },
  container: {
    flex: 1,
    justifyContent: 'flex-end', // Shift content to the bottom
    alignItems: 'center',
    padding: 40,
    paddingBottom: 90, // Add extra padding at the bottom for spacing
  },
  imageButton: {
    width: 200, // Adjust button width
    height: 100, // Adjust button height
    marginVertical: 9,
  },
  image: {
    width: '100%',
    height: '100%',
  },
});

export default HomeScreen;
