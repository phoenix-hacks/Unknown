import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TextInput,
  Alert,
  StyleSheet,
  TouchableOpacity,
  Image,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { RootStackParamList } from '../types';

type SignInScreenNavigationProp = NativeStackNavigationProp<
  RootStackParamList,
  'SignInScreen'
>;

const SignInScreen: React.FC = () => {
  const navigation = useNavigation<SignInScreenNavigationProp>();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const fixedPassword = '123456'; // Replace with a secure password system in production

  useEffect(() => {
    const checkUserLoggedIn = async () => {
      const storedUsername = await AsyncStorage.getItem('username');
      if (storedUsername) {
        navigation.navigate('HomeScreen');
      }
    };
    checkUserLoggedIn();
  }, []);

  const handleSignIn = async () => {
    if (password === fixedPassword) {
      await AsyncStorage.setItem('username', username);
      Alert.alert('Sign In Successful', `Welcome, ${username}!`);
      navigation.navigate('HomeScreen');
    } else {
      Alert.alert('Sign In Failed', 'Incorrect password.');
    }
  };

  return (
    <View style={styles.container}>
      {/* Background Image */}
      <Image
        source={require('../assets/login.png')} // Background image
        style={styles.backgroundImage}
        resizeMode="cover"
      />
      <View style={styles.formContainer}>
        <TextInput
          style={styles.input}
          placeholder="Username"
          value={username}
          onChangeText={setUsername}
        />
        <TextInput
          style={styles.input}
          placeholder="Password"
          value={password}
          onChangeText={setPassword}
          secureTextEntry
        />
        <TouchableOpacity style={styles.signInButton} onPress={handleSignIn}>
          <Text style={styles.signInButtonText}>Sign In</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  backgroundImage: {
    position: 'absolute',
    width: '100%',
    height: '100%',
  },
  formContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 25,
    textAlign: 'center',
    color: '#fff', // White text for better visibility on background
  },
  input: {
    width: '90%',
    padding: 10,
    marginBottom: 20,
    borderWidth: 1,
    borderRadius: 8,
    borderColor: '#ccc',
    backgroundColor: '#fff',
  },
  signInButton: {
    backgroundColor: '#FA4A0C', // Updated button color
    paddingVertical: 10,
    paddingHorizontal: 30,
    borderRadius: 8,
  },
  signInButtonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
});

export default SignInScreen;
